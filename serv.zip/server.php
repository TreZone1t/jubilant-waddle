<?php
// Get username and password from POST request
$username = $_POST['username'];
$password = $_POST['password'];

// Perform login validation
if ($username === '01551353638' && $password === '01000100awe0') {
  $response = array('success' => true, 'message' => 'Login successful!');
} else {
  $response = array('success' => false, 'message' => 'Invalid username or password');
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>